setwd("C:\\Users\\iworld\\Desktop\\IT24102434")
getwd()

#i

Observed_counts <- c(120, 95, 85, 100)

#ii

probabilities <- c(0.25, 0.25, 0.25, 0.25)

#iii
 
chisq.test(x = Observed_counts, p = probabilities )
