## Q1

setwd("C:\\Users\\it24102434\\Desktop\\IT24102434")
getwd()

Delivery_Times <- read.table("Exercise - Lab 05.txt",header=TRUE)
print(Delivery_Times)


## Q2

hist(Delivery_Times$Delivery, breaks=seq(20,70,by=5), right=TRUE,main = "Histogram of Delivery Times",xlab="Delivery_times",ylab="Frequency")

## Q4

Delivery_Times_freq <- hist(Delivery_Times$Delivery, 
                            breaks = seq(20,70,by=5),
                            right=TRUE,
                            plot=FALSE)
cumulative_freq <- cumsum(Delivery_Times_freq$counts)

plot(Delivery_Times_freq$mids, cumulative_freq, type = "o",
     main = "Cumulative Frequency Polygon (Ogive) of Delivery Times",
     xlab = "Delivery Times",
     ylab = "Cumulative Frequency",
     pch=16)
